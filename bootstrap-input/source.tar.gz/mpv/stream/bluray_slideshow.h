/* Bounds-checked MPLS type-2 (browsable slideshow audio) metadata.
 * Keep this independent of libbluray's private, ABI-unstable MPLS structs. */
#ifndef MP_BLURAY_SLIDESHOW_H
#define MP_BLURAY_SLIDESHOW_H
#include <stdbool.h>
#include <stdint.h>
#include <stddef.h>
#include <string.h>

struct bd_slideshow_clip {
    char clip[6];
    uint32_t in_time, out_time;
    bool repeat;
};

static uint32_t bd_slide_be(const uint8_t *p, int n)
{
    uint32_t v = 0;
    while (n--) v = (v << 8) | *p++;
    return v;
}

static bool bd_slideshow_parse(const uint8_t *data, size_t size, int subpath,
                               struct bd_slideshow_clip *out)
{
    if (!data || size < 40 || subpath < 0 || memcmp(data, "MPLS", 4))
        return false;
    size_t pos = bd_slide_be(data + 8, 4);
    if (pos > size || size - pos < 10) return false;
    size_t len = bd_slide_be(data + pos, 4);
    if (len < 6 || len > size - pos - 4) return false;
    size_t end = pos + 4 + len;
    int count = bd_slide_be(data + pos + 6, 2);
    int subs = bd_slide_be(data + pos + 8, 2);
    if (subpath >= subs) return false;
    pos += 10;
    for (int i = 0; i < count; i++) {
        if (end - pos < 2) return false;
        len = bd_slide_be(data + pos, 2);
        if (len > end - pos - 2) return false;
        pos += 2 + len;
    }
    for (int i = 0; i <= subpath; i++) {
        if (end - pos < 4) return false;
        len = bd_slide_be(data + pos, 4);
        pos += 4;
        if (len > end - pos) return false;
        if (i != subpath) { pos += len; continue; }
        // The asynchronous audio loop is one clip. Reject unsupported
        // multi-clip sequences rather than playing an incorrect segment.
        if (len < 36 || data[pos + 1] != 2 || data[pos + 5] != 1)
            return false;
        size_t item_len = bd_slide_be(data + pos + 6, 2);
        if (item_len < 28 || item_len > len - 8) return false;
        const uint8_t *item = data + pos + 8;
        if (memcmp(item + 5, "M2TS", 4) || (item[12] & 1)) return false;
        for (int j = 0; j < 5; j++)
            if (item[j] < '0' || item[j] > '9') return false;
        *out = (struct bd_slideshow_clip){
            .in_time = bd_slide_be(item + 14, 4),
            .out_time = bd_slide_be(item + 18, 4),
            .repeat = (data[pos + 3] & 1) != 0,
        };
        memcpy(out->clip, item, 5);
        return out->out_time > out->in_time;
    }
    return false;
}
#endif
