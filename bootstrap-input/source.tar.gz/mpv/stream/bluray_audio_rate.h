/*
 * This file is part of mpv and is licensed under the GNU Lesser General
 * Public License, version 2.1 or later.
 */
#ifndef MP_BLURAY_AUDIO_RATE_H
#define MP_BLURAY_AUDIO_RATE_H

#include <stdbool.h>
#include <string.h>
#include <libbluray/bluray.h>

// MPLS rates describe the complete presentation. Combined rates also describe
// a lower-rate AC-3/DTS compatibility core, so match the demuxed codec first.
static inline int mp_bluray_audio_sample_rate(int coding_type, int rate,
                                            const char *codec)
{
    if (!codec)
        return 0;

    bool hd = false;
    switch (coding_type) {
    case BLURAY_STREAM_TYPE_AUDIO_LPCM:
        if (strcmp(codec, "pcm_bluray")) return 0;
        break;
    case BLURAY_STREAM_TYPE_AUDIO_AC3:
        if (strcmp(codec, "ac3")) return 0;
        break;
    case BLURAY_STREAM_TYPE_AUDIO_DTS:
        if (strcmp(codec, "dts")) return 0;
        break;
    case BLURAY_STREAM_TYPE_AUDIO_TRUHD:
        // lavf can expose the interleaved AC-3 companion with the same PID.
        if (!strcmp(codec, "ac3"))
            return rate == BLURAY_AUDIO_RATE_48 ||
                   rate == BLURAY_AUDIO_RATE_96 ||
                   rate == BLURAY_AUDIO_RATE_192 ||
                   rate == BLURAY_AUDIO_RATE_96_COMBO ||
                   rate == BLURAY_AUDIO_RATE_192_COMBO ? 48000 : 0;
        if (strcmp(codec, "truehd")) return 0;
        hd = true;
        break;
    case BLURAY_STREAM_TYPE_AUDIO_DTSHD:
    case BLURAY_STREAM_TYPE_AUDIO_DTSHD_MASTER:
    case BLURAY_STREAM_TYPE_AUDIO_DTSHD_SECONDARY:
        if (strcmp(codec, "dts")) return 0;
        hd = true;
        break;
    case BLURAY_STREAM_TYPE_AUDIO_AC3PLUS:
    case BLURAY_STREAM_TYPE_AUDIO_AC3PLUS_SECONDARY:
        if (strcmp(codec, "eac3")) return 0;
        break;
    default:
        return 0;
    }

    switch (rate) {
    case BLURAY_AUDIO_RATE_48:  return 48000;
    case BLURAY_AUDIO_RATE_96:  return 96000;
    case BLURAY_AUDIO_RATE_192: return 192000;
    case BLURAY_AUDIO_RATE_96_COMBO:
        return hd ? 96000 : 48000;
    case BLURAY_AUDIO_RATE_192_COMBO:
        // The core can be either 48 or 96 kHz; do not guess when only the
        // core was demuxed. The complete TrueHD/DTS-HD presentation is 192 kHz.
        return hd ? 192000 : 0;
    default:
        return 0;
    }
}

#endif
