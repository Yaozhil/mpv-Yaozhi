/* SPDX-License-Identifier: LGPL-2.1-or-later */
#ifndef MP_VIDEO_PTS_REPAIR_H
#define MP_VIDEO_PTS_REPAIR_H

#include <math.h>
#include <stdbool.h>

// Only proven reordered/broken packet PTS with explicit container duration.
// Recover a bounded monotonic prefix without inventing a nominal-FPS clock.
struct mp_video_pts_repair {
    bool valid, active, blocked, recovering;
    double raw, duration, quantum;
};

static inline double mp_video_pts_repair_apply(struct mp_video_pts_repair *s,
    bool eligible, double raw, double previous, double duration, double quantum)
{
    if (s->blocked)
        return raw;
    bool was_active = s->active;
    bool metadata = eligible && isfinite(raw) && isfinite(previous) &&
        isfinite(duration) && duration > 0 && isfinite(quantum) && quantum > 0 &&
        quantum <= duration / 4;
    if (!metadata) {
        *s = (struct mp_video_pts_repair){.blocked = was_active};
        return raw;
    }
    bool current = s->valid && s->duration == duration && s->quantum == quantum;
    bool active = current && s->active;
    bool recovering = current && s->recovering;
    double last_raw = s->raw;
    *s = (struct mp_video_pts_repair){
        .valid = true, .raw = raw, .duration = duration, .quantum = quantum,
    };
    if (!current || raw < last_raw) {
        s->blocked = was_active;
        return raw;
    }
    // A monotonic source tail can catch up without a backwards output step.
    // Recovery does not invent another frame duration or extend the bound.
    if (recovering) {
        if (raw >= previous)
            return raw;
        s->active = s->recovering = true;
        return previous;
    }
    double next = previous + duration;
    if (!isfinite(next) || next <= previous) {
        s->blocked = active;
        return raw;
    }
    if (active && raw > previous && raw >= next - quantum)
        return raw;
    if (!active && !(raw == last_raw && raw == previous))
        return raw;
    double correction = next - raw;
    if (!(correction > 0 && correction <= duration + quantum)) {
        // Eligibility and metadata remain valid, and raw did not go backwards.
        // The previous correction was bounded; holding it remains bounded.
        if (active && previous >= raw && previous - raw <= duration + quantum) {
            s->active = s->recovering = true;
            return previous;
        }
        s->blocked = active;
        return raw;
    }
    s->active = true;
    return next;
}

#endif
