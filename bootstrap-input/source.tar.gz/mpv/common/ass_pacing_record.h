#ifndef MP_ASS_PACING_RECORD_H
#define MP_ASS_PACING_RECORD_H

#include <stdbool.h>
#include <stdint.h>
#include <string.h>

struct mpv_global;

// Internal diagnostic schema. Every v[]/flags interpretation is kind-local.
// Recording is independent of all scheduling/quality/presentation policies.
enum mp_ass_pacing_kind {
    MP_ASS_PACING_CONFIG = 1,
    MP_ASS_PACING_QUEUE,
    MP_ASS_PACING_PLAN,
    MP_ASS_PACING_DRAW,
    MP_ASS_PACING_SAMPLE,
    MP_ASS_PACING_ASS_TS,
    MP_ASS_PACING_CPU,
    MP_ASS_PACING_SUBMIT,
    MP_ASS_PACING_FEEDBACK,
    MP_ASS_PACING_LIFECYCLE,
    MP_ASS_PACING_MISS,
    MP_ASS_PACING_PREPASS,
    MP_ASS_PACING_SCHEDULE,
    MP_ASS_PACING_FLIP_BUDGET,
    MP_ASS_PACING_PHYSICAL,
    MP_ASS_PACING_REGISTER,
    MP_ASS_PACING_CACHE_EXECUTION,
    MP_ASS_PACING_WAIT,
    MP_ASS_PACING_CACHE_RESCHEDULE,
    MP_ASS_PACING_GPU_STAGE,
    MP_ASS_PACING_GUARD,
    MP_ASS_PACING_DXGI,
    MP_ASS_PACING_GPU_MARKER,
    MP_ASS_PACING_ANCHOR,
    // Optional CPU call spans. v = {stage, detail, cumulative_cpu_estimate_ns,
    //                              precise_wait_id (stages 230..239 only)}.
    // flags bit 0: CPU estimate available. Never GPU Ready/Display authority.
    MP_ASS_PACING_SPAN,
    MP_ASS_PACING_BOOTSTRAP,
    MP_ASS_PACING_BOOTSTRAP_STATE,
    MP_ASS_PACING_BOOTSTRAP_ORIGIN,
    MP_ASS_PACING_BOOTSTRAP_VIDEO,
    MP_ASS_PACING_BOOTSTRAP_SELECT,
    MP_ASS_PACING_KIND_LIMIT = 64,
};

struct mp_ass_pacing_record {
    int64_t event_ns;
    uint64_t vo_seq;
    uint64_t draw_seq;
    uint64_t frame_id;
    uint64_t sample_seq;
    uint64_t generation;
    uint64_t epoch;
    uint64_t flags;
    int64_t v[16];
};

// A compile-time size assertion also works in small C99 native fixtures.
typedef char mp_ass_pacing_double_is_64_bits[
    sizeof(double) == 8 && sizeof(int64_t) == 8 ? 1 : -1];

// Bit-preserving storage includes NaN/unknown values; never coerce to integer PTS.
static inline int64_t mp_ass_pacing_double_bits(double value)
{
    int64_t bits;
    memcpy(&bits, &value, sizeof(bits));
    return bits;
}

// Init/flush belong to the instance owner, before/after all producers exist.
// An absent environment variable is a successful no-op. A requested invalid,
// conflicting or unwritable sink returns false and leaves recording disabled.
bool mp_ass_pacing_init(struct mpv_global *global);
bool mp_ass_pacing_flush(struct mpv_global *global);
bool mp_ass_pacing_enabled(struct mpv_global *global);

// No timestamp sampling, allocation, locks, formatting or I/O in these calls.
// IDs are instance-unique. The caller explicitly carries VO/draw/sample scopes.
uint64_t mp_ass_pacing_next_vo(struct mpv_global *global);
uint64_t mp_ass_pacing_next_draw(struct mpv_global *global);
uint64_t mp_ass_pacing_next_sample(struct mpv_global *global);
void mp_ass_pacing_record(struct mpv_global *global, uint32_t kind,
                         const struct mp_ass_pacing_record *record);

#define MP_ASS_PACING_FORMAT_VERSION 1
#define MP_ASS_PACING_HEADER_BYTES 128
#define MP_ASS_PACING_RECORD_BYTES 208
#define MP_ASS_PACING_FOOTER_BYTES 128
#define MP_ASS_PACING_DEFAULT_CAPACITY 200000
#define MP_ASS_PACING_MIN_CAPACITY 1024
#define MP_ASS_PACING_MAX_CAPACITY 1048576

#endif
