/*
 * This file is part of mpv.
 *
 * mpv is free software; you can redistribute it and/or modify it under the
 * terms of the GNU Lesser General Public License, version 2.1 or later.
 */

#include <errno.h>
#include <limits.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>

#ifdef _WIN32
#include <windows.h>
#include <winnls.h>
#else
#include <stdatomic.h>
#include <fcntl.h>
#include <unistd.h>
#endif

#include "ass_pacing_record.h"
#include "global.h"
#include "osdep/timer.h"

#ifdef _WIN32
// Existing UTF-8 environment accessor (osdep/io.c). Avoid its broad I/O macro
// wrappers here: this file uses an exclusive native handle, not stdio sinks.
char *mp_getenv(const char *name);
#define pacing_getenv mp_getenv
#else
#define pacing_getenv getenv
#endif

// Windows Interlocked operations are lock-free native 64-bit operations; this
// also lets the exact Windows implementation run in small native C fixtures.
#ifdef _WIN32
typedef volatile LONG64 pacing_atomic;
static void counter_init(pacing_atomic *value)
{
    *value = 0;
}
static uint64_t counter_next(pacing_atomic *value)
{
    LONG64 old = InterlockedCompareExchange64(value, 0, 0);
    for (;;) {
        LONG64 next = (LONG64)((uint64_t)old + 1);
        LONG64 previous = InterlockedCompareExchange64(value, next, old);
        if (previous == old)
            return (uint64_t)next;
        old = previous;
    }
}
static uint64_t counter_read(pacing_atomic *value)
{
    return (uint64_t)InterlockedCompareExchange64(value, 0, 0);
}
static void counter_publish(pacing_atomic *value, uint64_t data)
{
    InterlockedExchange64(value, (LONG64)data);
}
#else
typedef _Atomic uint64_t pacing_atomic;
static void counter_init(pacing_atomic *value)
{
    atomic_init(value, 0);
}
static uint64_t counter_next(pacing_atomic *value)
{
    return atomic_fetch_add_explicit(value, 1, memory_order_relaxed) + 1;
}
static uint64_t counter_read(pacing_atomic *value)
{
    return atomic_load_explicit(value, memory_order_acquire);
}
static void counter_publish(pacing_atomic *value, uint64_t data)
{
    atomic_store_explicit(value, data, memory_order_release);
}
#endif

struct pacing_slot {
    pacing_atomic published;
    uint32_t kind, producer;
    struct mp_ass_pacing_record record;
};

struct mp_ass_pacing_state {
    struct pacing_slot *slots;
    uint64_t capacity;
    pacing_atomic attempted, vo_seq, draw_seq, sample_seq, invalid;
    uint64_t pid, nonce, frequency, raw_at_init, mp_at_init, raw_offset, clock_kind;
#ifdef _WIN32
    HANDLE sink;
#else
    int sink;
#endif
};

static bool absolute_path(const char *path)
{
#ifdef _WIN32
    if (((path[0] >= 'A' && path[0] <= 'Z') ||
         (path[0] >= 'a' && path[0] <= 'z')) && path[1] == ':' &&
        (path[2] == '/' || path[2] == '\\'))
        return true;
    // Reject device/pipe namespaces; only a complete server/share UNC path.
    if (path[0] != '\\' || path[1] != '\\' || !path[2] ||
        path[2] == '?' || path[2] == '.')
        return false;
    const char *share = strchr(path + 2, '\\');
    if (!share || share == path + 2 || !share[1])
        return false;
    const char *file = strchr(share + 1, '\\');
    return file && file > share + 1 && file[1];
#else
    return path[0] == '/';
#endif
}

static bool parse_capacity(uint64_t *capacity)
{
    const char *value = pacing_getenv("MPV_NATIVE_ASS_RECORD_CAPACITY");
    *capacity = MP_ASS_PACING_DEFAULT_CAPACITY;
    if (!value || !value[0])
        return true;
    uint64_t result = 0;
    for (const char *p = value; *p; p++) {
        if (*p < '0' || *p > '9' || result > MP_ASS_PACING_MAX_CAPACITY / 10)
            return false;
        result = result * 10 + (*p - '0');
        if (result > MP_ASS_PACING_MAX_CAPACITY)
            return false;
    }
    if (result < MP_ASS_PACING_MIN_CAPACITY)
        return false;
    *capacity = result;
    return true;
}

static bool open_sink(struct mp_ass_pacing_state *state, const char *path)
{
#ifdef _WIN32
    int length = MultiByteToWideChar(CP_UTF8, MB_ERR_INVALID_CHARS, path, -1,
                                   NULL, 0);
    if (length <= 0 || length > 32000)
        return false;
    wchar_t *wide = malloc((size_t)length * sizeof(*wide));
    if (!wide)
        return false;
    bool converted = MultiByteToWideChar(CP_UTF8, MB_ERR_INVALID_CHARS, path, -1,
                                       wide, length) == length;
    state->sink = converted ? CreateFileW(wide, GENERIC_WRITE, 0, NULL,
                              CREATE_NEW, FILE_ATTRIBUTE_NORMAL, NULL)
                            : INVALID_HANDLE_VALUE;
    free(wide);
    return state->sink != INVALID_HANDLE_VALUE;
#else
    int flags = O_WRONLY | O_CREAT | O_EXCL;
#ifdef O_CLOEXEC
    flags |= O_CLOEXEC;
#endif
    state->sink = open(path, flags, 0600);
    return state->sink >= 0;
#endif
}

static bool initialize_clock(struct mp_ass_pacing_state *state)
{
#ifdef _WIN32
    LARGE_INTEGER frequency, qpc;
    if (!QueryPerformanceFrequency(&frequency) || frequency.QuadPart <= 0 ||
        frequency.QuadPart >= INT64_C(2900000000) ||
        !QueryPerformanceCounter(&qpc) || qpc.QuadPart <= 0)
        return false;
    state->frequency = frequency.QuadPart;
    state->raw_at_init = qpc.QuadPart;
    uint64_t raw_ns = state->raw_at_init / state->frequency * UINT64_C(1000000000)
        + state->raw_at_init % state->frequency * UINT64_C(1000000000)
          / state->frequency;
    state->pid = GetCurrentProcessId();
    state->clock_kind = 1; // raw_at_init is QPC units.
#else
    uint64_t raw_ns = mp_raw_time_ns();
    state->raw_at_init = raw_ns;
    state->frequency = UINT64_C(1000000000);
    state->pid = getpid();
    state->clock_kind = 2; // raw_at_init is raw monotonic nanoseconds.
#endif
    state->mp_at_init = mp_time_ns_from_raw_time(raw_ns);
    state->raw_offset = raw_ns - state->mp_at_init;
    state->nonce = state->raw_at_init ^ (state->pid << 32);
    return true;
}

bool mp_ass_pacing_init(struct mpv_global *global)
{
    if (!global || global->ass_pacing)
        return false;
    const char *path = pacing_getenv("MPV_NATIVE_ASS_RECORD");
    if (!path || !path[0])
        return true;
    uint64_t capacity;
    if (!absolute_path(path) || !parse_capacity(&capacity) ||
        capacity > SIZE_MAX / sizeof(struct pacing_slot))
        return false;
    struct mp_ass_pacing_state *state = calloc(1, sizeof(*state));
    if (!state)
        return false;
    state->capacity = capacity;
    counter_init(&state->attempted);
    counter_init(&state->vo_seq);
    counter_init(&state->draw_seq);
    counter_init(&state->sample_seq);
    counter_init(&state->invalid);
    state->slots = calloc((size_t)capacity, sizeof(*state->slots));
    if (!state->slots || !initialize_clock(state)) {
        free(state->slots);
        free(state);
        return false;
    }
    // Commit the buffer pages before playback; do not defer first page faults
    // to the measured producer path. No producer exists until init returns.
    volatile unsigned char *pages = (volatile unsigned char *)state->slots;
    size_t bytes = (size_t)capacity * sizeof(*state->slots);
    for (size_t n = 0; n < bytes; n += 4096)
        pages[n] = 0;
    pages[bytes - 1] = 0;
    for (uint64_t n = 0; n < capacity; n++)
        counter_init(&state->slots[n].published);
    if (!open_sink(state, path)) {
        free(state->slots);
        free(state);
        return false;
    }
    // Instance ownership is immutable until all producers have stopped.
    global->ass_pacing = state;
    return true;
}

bool mp_ass_pacing_enabled(struct mpv_global *global)
{
    return global && global->ass_pacing;
}

uint64_t mp_ass_pacing_next_vo(struct mpv_global *global)
{
    return mp_ass_pacing_enabled(global)
        ? counter_next(&global->ass_pacing->vo_seq) : 0;
}

uint64_t mp_ass_pacing_next_draw(struct mpv_global *global)
{
    return mp_ass_pacing_enabled(global)
        ? counter_next(&global->ass_pacing->draw_seq) : 0;
}

uint64_t mp_ass_pacing_next_sample(struct mpv_global *global)
{
    return mp_ass_pacing_enabled(global)
        ? counter_next(&global->ass_pacing->sample_seq) : 0;
}

void mp_ass_pacing_record(struct mpv_global *global, uint32_t kind,
                         const struct mp_ass_pacing_record *record)
{
    if (!mp_ass_pacing_enabled(global))
        return;
    struct mp_ass_pacing_state *state = global->ass_pacing;
    if (!record || !kind || kind >= MP_ASS_PACING_KIND_LIMIT) {
        counter_next(&state->invalid);
        return;
    }
    uint64_t seq = counter_next(&state->attempted);
    if (seq > state->capacity)
        return; // Keep monotonic attempted count; never recycle/overwrite.
    struct pacing_slot *slot = &state->slots[seq - 1];
    slot->kind = kind;
#ifdef _WIN32
    slot->producer = GetCurrentThreadId();
#else
    slot->producer = 0; // No guessed portable thread identity.
#endif
    slot->record = *record;
    counter_publish(&slot->published, seq);
}

struct pacing_writer {
    struct mp_ass_pacing_state *state;
    unsigned char buffer[16384];
    size_t used;
    bool failed;
};

static bool sink_write(struct mp_ass_pacing_state *state,
                       const unsigned char *data, size_t size)
{
    while (size) {
#ifdef _WIN32
        DWORD written = 0;
        DWORD chunk = size > UINT32_MAX ? UINT32_MAX : (DWORD)size;
        if (!WriteFile(state->sink, data, chunk, &written, NULL) || !written)
            return false;
#else
        ssize_t written = write(state->sink, data, size);
        if (written < 0 && errno == EINTR)
            continue;
        if (written <= 0)
            return false;
#endif
        data += written;
        size -= written;
    }
    return true;
}

static void writer_flush(struct pacing_writer *writer)
{
    if (!writer->failed && writer->used)
        writer->failed = !sink_write(writer->state, writer->buffer, writer->used);
    writer->used = 0;
}

static void writer_bytes(struct pacing_writer *writer,
                         const unsigned char *data, size_t size)
{
    while (size && !writer->failed) {
        size_t available = sizeof(writer->buffer) - writer->used;
        size_t chunk = size < available ? size : available;
        memcpy(writer->buffer + writer->used, data, chunk);
        writer->used += chunk;
        data += chunk;
        size -= chunk;
        if (writer->used == sizeof(writer->buffer))
            writer_flush(writer);
    }
}

static void store_u32(unsigned char *out, uint32_t value)
{
    for (unsigned n = 0; n < 4; n++)
        out[n] = value >> (n * 8);
}

static void store_u64(unsigned char *out, uint64_t value)
{
    for (unsigned n = 0; n < 8; n++)
        out[n] = value >> (n * 8);
}

bool mp_ass_pacing_flush(struct mpv_global *global)
{
    if (!mp_ass_pacing_enabled(global))
        return true;
    struct mp_ass_pacing_state *state = global->ass_pacing;
    // Owner calls only after producer joins/OSD teardown. No live IPC flush.
    global->ass_pacing = NULL;
    struct pacing_writer writer = {.state = state};
    unsigned char header[MP_ASS_PACING_HEADER_BYTES] = {0};
    memcpy(header, "YASSREC1", 8);
    store_u32(header + 8, MP_ASS_PACING_FORMAT_VERSION);
    store_u32(header + 12, sizeof(header));
    store_u32(header + 16, MP_ASS_PACING_RECORD_BYTES);
    store_u32(header + 20, MP_ASS_PACING_FOOTER_BYTES);
    store_u64(header + 24, state->capacity);
    store_u64(header + 32, state->pid);
    store_u64(header + 40, state->nonce);
    store_u64(header + 48, state->frequency);
    store_u64(header + 56, state->raw_at_init);
    store_u64(header + 64, state->mp_at_init);
    store_u64(header + 72, state->raw_offset);
    store_u64(header + 80, state->clock_kind);
    store_u64(header + 88, 1); // little-endian, complete footer required
    writer_bytes(&writer, header, sizeof(header));

    uint64_t attempted = counter_read(&state->attempted);
    uint64_t rows = attempted < state->capacity ? attempted : state->capacity;
    uint64_t overflow = attempted - rows;
    uint64_t published = 0, checksum = UINT64_C(14695981039346656037);
    for (uint64_t n = 0; n < rows; n++) {
        struct pacing_slot *slot = &state->slots[n];
        unsigned char wire[MP_ASS_PACING_RECORD_BYTES] = {0};
        store_u64(wire, n + 1);
        if (counter_read(&slot->published) == n + 1) {
            published++;
            store_u32(wire + 8, slot->kind);
            store_u32(wire + 12, slot->producer);
            const struct mp_ass_pacing_record *r = &slot->record;
            uint64_t fields[] = {(uint64_t)r->event_ns, r->vo_seq, r->draw_seq,
                r->frame_id, r->sample_seq, r->generation, r->epoch, r->flags};
            for (unsigned k = 0; k < 8; k++)
                store_u64(wire + 16 + k * 8, fields[k]);
            for (unsigned k = 0; k < 16; k++)
                store_u64(wire + 80 + k * 8, (uint64_t)r->v[k]);
        } // Unpublished reserved slot stays a kind=0 tombstone, not omitted.
        for (size_t k = 0; k < sizeof(wire); k++) {
            checksum ^= wire[k];
            checksum *= UINT64_C(1099511628211);
        }
        writer_bytes(&writer, wire, sizeof(wire));
    }
    uint64_t invalid = counter_read(&state->invalid);
    uint64_t partial = rows - published;
    bool complete = !overflow && !partial && !invalid;
    unsigned char footer[MP_ASS_PACING_FOOTER_BYTES] = {0};
    memcpy(footer, "YASSEND1", 8);
    store_u32(footer + 8, MP_ASS_PACING_FORMAT_VERSION);
    store_u32(footer + 12, sizeof(footer));
    store_u64(footer + 16, attempted);
    store_u64(footer + 24, rows);
    store_u64(footer + 32, published);
    store_u64(footer + 40, overflow);
    store_u64(footer + 48, partial);
    store_u64(footer + 56, counter_read(&state->draw_seq));
    store_u64(footer + 64, counter_read(&state->sample_seq));
    store_u64(footer + 72, counter_read(&state->vo_seq));
    store_u64(footer + 80, checksum);
    store_u64(footer + 88, complete);
    store_u64(footer + 96, invalid);
    writer_bytes(&writer, footer, sizeof(footer));
    writer_flush(&writer);
#ifdef _WIN32
    bool closed = CloseHandle(state->sink) != 0;
#else
    bool closed = close(state->sink) == 0;
#endif
    bool success = complete && !writer.failed && closed;
    free(state->slots);
    free(state);
    return success;
}
